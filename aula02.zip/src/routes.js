const express = require('express');
const routes = express.Router();

routes.post('/login', (req, res)=>{
  // res.send('login ');
  const {email, password} = req.body;
  res.send(email);

});

module.exports = routes;